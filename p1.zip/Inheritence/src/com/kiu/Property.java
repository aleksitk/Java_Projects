package com.kiu;

public interface Property {

    boolean test(Object r);


}
