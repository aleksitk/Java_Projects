package com.kiu;

public class Main{

    public static void main(String[] args) {
        Property p = (Object r) ->  (r != null);

    }

}
