package com.kiu;

public class CheckArray {
    public boolean check(Object[] r, Property p){
        for(int i = 0; i < r.length; i++)
            if(p.test(r[i])) return true;
            return false;
    }
}
