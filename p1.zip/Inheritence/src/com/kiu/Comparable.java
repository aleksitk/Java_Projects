package com.kiu;

public interface Comparable {
      int x = 0;

    static int compare(Comparable x, Comparable y) {
        if ((x == null) && (y == null)) return 0;
        else if (x == null) return -1;
        else if (y == null) return 1;
        else return x.compareTo(y);
    }

    int compareTo(Object x);

}
