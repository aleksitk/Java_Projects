package com.kiu;

public class Rational extends AddSubMulDiv implements Comparable{
    private int numer, denom;

    public Rational(int numer, int denom) {
        this.numer = numer;
        this.denom = denom;
    }

    @Override
    public int compareTo(Object cmp) {
        Rational fraction = (Rational) cmp;
        long left = (long) numer * (long) fraction.denom;
        long right = (long) denom * (long) fraction.numer;
        if (left == right) return 0;
        else if (left < right) return -1;
        else return 1;
    }

    
}
