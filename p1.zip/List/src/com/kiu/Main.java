package com.kiu;

public class Main extends MiniJava{

    public static void main(String[] args) {
	List d1 = new List(42);
    List d2 = new List(2,d1);
    List d3 = new List(60,d2);
    List d4 = new List(-3,d3);
    List l1 = new List(16);
    List l2 = new List(15,l1);
    List l3 = new List(0,l2);
    //write("" + List.sort(d4));
    int[] a = new int[]{1,3,7,9,30};
    int[] b = new int[]{5,8,9,15,50};
    int[] c = arraymerging(a,b);
    //for(int i = 0; i < c.length; i++)   writeConsole(c[i]+", ");
    int[] f = sortarr(new int[]{1,150, 510, 15, 70, 90, 3});
    for(int i = 0; i < f.length; i++)   writeConsole(f[i]+", ");
    }


    public static int[] arraymerging(int[] a, int[] b){
        int n = a.length + b.length;
        int[] result = new int[n];
        int an = 0, bn = 0, s;
        for (s = 0; s < n; s++){
            if(an == a.length || bn == b.length) break;
            if(a[an] > b[bn]) { result[s] = b[bn]; bn++; }
            else { result[s]  = a[an]; an++;}
        }
        if(an == a.length)
            for(int k = s; k < n; k++){ result[k] = b[bn]; bn++; }
        else if(bn == b.length)
            for(int k = s; k < n; k++){ result[k] = a[an]; an++; }
        return result;
    }



    public static int[] sortarr(int[] a) {
        int[] x, y;
        y = new int[a.length / 2];
        if(a.length == 1) return a;

        if (a.length % 2 == 0) {
            x = new int[a.length / 2];
            for(int i = 0; i < a.length; i+=2) x[i/2] = a[i];
            for(int i = 1; i < a.length; i+=2) y[(i-1)/2] = a[i];
        }

        else {
            x = new int[a.length / 2 + 1];
            for(int i = 0; i < a.length; i+=2) x[i/2] = a[i];
            for(int i = 1; i < a.length; i+=2) y[(i-1)/2] = a[i];
        } //half

        x = sortarr(x);
        y = sortarr(y);
        return arraymerging(x,y);       //wow

    }



}
