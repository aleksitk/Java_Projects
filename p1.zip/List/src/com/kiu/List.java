package com.kiu;

public class List {
    public int info;
    public List next;

    public List (int info){
        this.info = info;
        next = null;
    }

    public List(int info, List next){
        this.info = info;
        this.next = next;
    }

    public void insert(int x){
        next = new List(x, next);
    }

    public void delete(){
        if (next != null) next = next.next;
    }

    public String toString(){
        List t;
        String result = "" + info;
        for(t = next; t != null; t = t.next){
            result += ", " + t.info;
        }
        return result;
    }

    public static boolean isEmpty(List l){
        return l == null;
    }

    public static String toString(List l){
        if(l == null) return "null";
        else return l.toString();
    }

    public static List arrayToList(int[] a){
        List l = null;
        for(int i = a.length - 1; i >= 0; i--)  l = new List(a[i], l);
         return l;
    }

    public int[] listToArray(){
        int size = length();
        int[] arr = new int[size];
        int count = 0;
        for(List t = this; t != null; t = t.next) {arr[count] = t.info; count++;}
        return arr;
    }

    private int length(){
        int size = 1;
        for(List t = next; t != null; t = t.next) size++;
        return size;
    }
    public static int length(List l){
        if(l == null) return -1;
        else return l.length();
    }

    public static List merge(List a, List b){
        if(a == null) return b;
        if(b == null) return a;
       if(a.info > b.info) {
           List n = merge(a,b.next);
          return new List(b.info,n);
       }
       else {
          List n = merge(a.next,b);
          return new List(a.info,n);
       }
    }
    public List half() {
        if (next == null) return null;
        List result = next;
        next = next.half();
        return result;
}
    public static List sort(List a){
        if(a.next == null) return a;
        List b = a.half();
        a = sort(a);
        b = sort(b);
        return merge(a,b);
    }

}
