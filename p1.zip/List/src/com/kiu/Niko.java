package com.kiu;

public class Niko extends MiniJava{
    public static void main(){

    }
}
