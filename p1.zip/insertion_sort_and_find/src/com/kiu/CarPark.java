package com.kiu;

public class CarPark {
    private int parkId;
    private int maxOcc;
    private String name;
    private int[] space;
    public CarPark(int parkId, int maxOcc, String name, int[] space){
        this.parkId = parkId;
        this.maxOcc = maxOcc;
        this.name = name;
        this.space = space;
    }
    public boolean check(int space_number){
        if(space[space_number] == 0)
            return true;

        else return false;
    }
    public boolean put(int space_number){

    }
}
