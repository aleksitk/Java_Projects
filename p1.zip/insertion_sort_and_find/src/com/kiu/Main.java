package com.kiu;

public class Main extends MiniJava {

    public static void main(String[] args) {
        write(find(sort(readArray(5)), 1));
    }

    public static int[] readArray(int size) {
        int[] arr = new int[size];
        int i = 0;
        for (; i < size; i++)
            arr[i] = readInt();
        return arr;
    }

    public static int min(int[] a) {
        int result = a[0];
        for (int i = 1; i < a.length; i++) if (a[i] < result) result = a[i];
        return result;
    }


    public static int[] sort(int[] a) {
        int[] b = new int[a.length];
        for (int i = 0; i < a.length; i++) {
            int j = 0;
            while (j < i && a[i] >= b[j]) j++;
            for (int k = i - 1; k >= j; k--) b[k + 1] = b[k];
            b[j] = a[i];
        }
        return b;
    }


    public static int find(int[] a, int x) {
        return find0(a, x, 0, a.length - 1);
    }

    public static int find0(int[] a, int x, int n1, int n2) {
        if (n1 > n2) return -1;
        int t = (n1 + n2) / 2;
        if (a[t] > x) return find0(a, x, n1, t - 1);
        else if (a[t] < x) return find0(a, x, t + 1, n2);
        else return t;

    }

}







