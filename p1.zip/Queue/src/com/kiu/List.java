package com.kiu;

public class List {
    public int info;
    public List next;

    public List(int info, List next) {
        this.info = info;
        this.next = next;
    }

    public List(int info) {
        this.info = info;
        next = null;
    }

    public String toString() {
        String result = "[" + info;
        for (List t = next; t != null; t = t.next)
            result = result + ", " + t.info;
        return result + "]";
    }

    public static String toString(List l){
        if(l == null) return "null";
        else return l.toString();
    }
}
