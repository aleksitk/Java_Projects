package com.kiu;

public class Cyclic {
    private int info;
    private Cyclic ref;
    public Cyclic(){
        info = 17;
        ref = this;
    }
}
