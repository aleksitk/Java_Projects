package com.kiu;

public class Main extends MiniJava {

    public static void main(String[] args) {

    }
}
