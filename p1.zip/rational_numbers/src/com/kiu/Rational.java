package com.kiu;

public class Rational {
    private int num;
    private final int den;

    public Rational(int num, int den){
        this.num = num;
        this.den = den;
    }

    public Rational(int num){
        this.num = num;
        den = 1;
    }

    public Rational add(Rational x){
            int denum = x.den * den;
            int numer = x.den * num + den * x.num;
            return new Rational(numer, denum);
    }

    public Rational shekveca(){
        int a = num;
        int b = den;
       while(a != b){
           if(a < b) b -= a;
           else a -= b;
       }

        return new Rational(num/a,den/a);
    }

    public boolean equals(Rational x){
        return x.num * den == x.den * num;
    }

    public String toString(){
        if(den == 1) return "" + num;
        if(den == 0) return "eRRor";
        if(den > 0) return num + "/" + den;
        else return -num + "/" + -den;
    }
    public static Rational[] intToRationalArray(int[] a){
        Rational[] result = new Rational[a.length];
        for(int i = 0; i < a.length; i++) result[i] = new Rational(a[i]);
        return result;
    }

    public void inc(int n){
        num += n * den;
    }
}
