package com.kiu;

public class Main extends MiniJava{

    public static void main(String[] args) {
	   int a,b;  // ALLOCATE 2
       a = readInt();  //STORE 0
       b = readInt();  //STORE 1
       while(a != b){  //LOAD 0 LOAD 1 NEQ
           if(a < b) b -= a;  // LOAD 0 LOAD 1 LESS LOAD 1 LOAD 0 SUB STORE 1
           else a -= b; //LOAD 0 LOAD 1 SUB STORE 0
       } //JUMP A
       write(a); //LOAD 0 WRITE HALT
    }
}

/*   JVM  -------------------------
      ALLOC 2
      READ
      STORE 0
      READ
      STORE 1
 A:   LOAD 0
      LOAD 1
      NEQ
      FJUMP D
      LOAD 0
      LOAD 1
      LESS
      FJUMP B
      LOAD 1
      LOAD 0
      SUB
      STORE 1
      JUMP C
 B:   LOAD 0
      LOAD 1
      SUB
      STORE 0
 C:   JUMP A
 D:   LOAD 0
      WRITE
      HALT

      A = 9; B = 11; C = 12; D = 13;
 */
