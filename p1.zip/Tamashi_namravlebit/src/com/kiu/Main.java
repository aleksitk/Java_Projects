package com.kiu;

public class Main extends MiniJava{

    public static void main(String[] args) {
        int x = readInt(),z;
        int y = z = 1;
        int i = 0;
        while(x > 9){
            String s = "" + x;
            int n = s.length();
            if(n % 2 == 0){
                y = (int) (x / Math.pow(10, n/2));
                z = (int) (x % Math.pow(10, n/2));
                write( (int) (y*Math.pow(10, n/2) + z));
            }
            else{
                y = (int) (x / Math.pow(10, n/2 + 1));
                z = (int) (x % Math.pow(10, n/2 + 1));
                write((int) (y*Math.pow(10, n/2 + 1) + z));
            }
            x = y * z;
            i++;
        }
        write(0);
        write("size == " + i);
    }

}
