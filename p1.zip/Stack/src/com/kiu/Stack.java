package com.kiu;

public class Stack {
    //private List l;
    private int[] a;
    private int sp;
    public Stack() {
        a = new int[4];
        sp = -1;
    }

    public boolean isEmpty(){
        return sp < 0;
    }

    public int[] getA() {   //for checkT
        return a;
    }

    public int pop() {
        int result = a[sp];
        if(sp == a.length/4 && a.length > 4){
            int[] b = new int[a.length/2];
            for(int i = 0; i <= sp; i++) b[i] = a[i];
            a = b;
        }
        sp--;
        return result;
    }

    public void push(int x){
        ++sp;
        if(sp == a.length){
            int[] b = new int[2*sp];
            for(int i = 0; i < sp; i++) b[i] = a[i];
            b[sp] = x;
            a = b;
        }
        a[sp] = x;
    }

    public String toString(){
       String result = "[ ";
        for (int i = 0; i <= sp; i++) result += a[i] + " ";
        return result + "]";
    }

}
