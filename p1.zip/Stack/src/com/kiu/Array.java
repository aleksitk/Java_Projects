package com.kiu;

public class Array {
    public int length;
    public Array(int[] a) {
         this.length = a.length;
    }

}
