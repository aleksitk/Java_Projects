package com.kiu;

public class Main extends MiniJava{

    public static void main(String[] args) {
	Stack s = new Stack();
    s.push(5);
    s.push(9);
    s.push(150);
    s.push(15);
    s.push(2);
    int[] a = s.getA();
    for(int i = 0; i < a.length; i++) writeConsole(a[i]+" ");
    write("");
    s.pop();
    s.pop();
    s.pop();
    s.push(150);
    s.push(12);
    a = s.getA();
    for(int i = 0; i < a.length; i++) writeConsole(a[i]+" ");
    }
}
