package com.kiu;

public class List {
    int info;
    List next;

    public List (int info){
        this.info = info;
        next = null;
    }

    public List(int info, List next) {
        this.info = info;
        this.next = next;
    }
    public String toString(){
        List t;
        String result = "" + info;
        for(t = next; t != null; t = t.next){
            result += ", " + t.info;
        }
        return result;
    }

    public static String toString(List l){
        if(l == null) return "null";
        else return l.toString();
    }

}
